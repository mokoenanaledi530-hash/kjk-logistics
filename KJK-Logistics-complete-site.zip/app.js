
document.addEventListener("DOMContentLoaded",()=>{
  const year=document.getElementById("year");
  if(year) year.textContent=new Date().getFullYear();

  const form=document.getElementById("quoteForm");
  if(form){
    form.addEventListener("submit",e=>{
      e.preventDefault();
      const data=new FormData(form);
      const name=(data.get("name")||"").trim();
      const phone=(data.get("phone")||"").trim();
      const message=(data.get("message")||"").trim();
      const text=`KJK LOGISTICS ENQUIRY\n\nCustomer: ${name}\nPhone/WhatsApp: ${phone}\n\nRequirements:\n${message}`;
      const status=document.getElementById("formStatus");
      status.textContent="Your enquiry is prepared. Add KJK's verified WhatsApp number to app.js to enable direct sending.";
      console.log(text);
    });
  }
});

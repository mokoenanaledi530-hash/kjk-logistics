
const PRODUCTS=[
["ENG-001","Diesel Air Filter","filters","Air filtration component for heavy-duty diesel applications",["Mercedes-Benz","Volvo","Scania","MAN","DAF"],"Various commercial vehicle applications"],
["ENG-002","Diesel Fuel Filter","filters","Diesel fuel filtration component",["Mercedes-Benz","Volvo","Scania","MAN","Iveco"],"Various diesel applications"],
["ENG-003","Engine Oil Filter","filters","Heavy-duty engine oil filtration component",["Mercedes-Benz","Volvo","Scania","MAN","DAF","Iveco"],"Various truck applications"],
["ENG-004","Water Pump","cooling","Diesel engine cooling water pump",["Mercedes-Benz","Volvo","Scania","MAN","DAF"],"Application dependent"],
["ENG-005","Engine Gasket Set","engine","Engine gasket components",["Mercedes-Benz","Volvo","Scania","MAN"],"Application dependent"],
["BRK-001","Heavy Duty Brake Pad Set","brakes","Commercial vehicle brake pad set",["Mercedes-Benz","Volvo","Scania","MAN","DAF"],"Application dependent"],
["BRK-002","Truck Brake Disc","brakes","Heavy-duty commercial vehicle brake disc",["Mercedes-Benz","Volvo","Scania","MAN","DAF"],"Application dependent"],
["BRK-003","Truck Brake Drum","brakes","Commercial truck brake drum",["Mercedes-Benz","Volvo","Scania","MAN","Hino","Isuzu"],"Application dependent"],
["BRK-004","Brake Chamber","brakes","Air brake chamber for commercial vehicles",["Mercedes-Benz","Volvo","Scania","MAN","DAF"],"Application dependent"],
["CLT-001","Heavy Duty Clutch Kit","clutch","Complete commercial vehicle clutch kit",["Mercedes-Benz","Volvo","Scania","MAN","DAF","Iveco"],"Application dependent"],
["CLT-002","Clutch Release Bearing","clutch","Commercial vehicle clutch release bearing",["Mercedes-Benz","Volvo","Scania","MAN"],"Application dependent"],
["GBX-001","Gearbox Bearing","gearbox","Heavy-duty transmission bearing",["Mercedes-Benz","Volvo","Scania","MAN"],"Application dependent"],
["GBX-002","Gearbox Seal","gearbox","Commercial vehicle gearbox sealing component",["Mercedes-Benz","Volvo","Scania","MAN","DAF"],"Application dependent"],
["DRV-001","Differential Bearing","drivetrain","Heavy-duty differential bearing",["Mercedes-Benz","Volvo","Scania","MAN","DAF"],"Application dependent"],
["DRV-002","Propshaft Component","drivetrain","Commercial vehicle driveline component",["Mercedes-Benz","Volvo","Scania","MAN","DAF"],"Application dependent"],
["SUS-001","Heavy Duty Shock Absorber","suspension","Truck suspension shock absorber",["Mercedes-Benz","Volvo","Scania","MAN","DAF"],"Application dependent"],
["SUS-002","Air Suspension Bag","suspension","Commercial truck air suspension component",["Mercedes-Benz","Volvo","Scania","MAN","DAF"],"Application dependent"],
["SUS-003","Suspension Bush","suspension","Heavy-duty suspension bush",["Mercedes-Benz","Volvo","Scania","MAN","Hino","Isuzu"],"Application dependent"],
["STR-001","Steering Component","steering","Heavy-duty commercial vehicle steering component",["Mercedes-Benz","Volvo","Scania","MAN","DAF"],"Application dependent"],
["STR-002","Tie Rod End","steering","Commercial vehicle steering linkage component",["Mercedes-Benz","Volvo","Scania","MAN","Isuzu","Hino"],"Application dependent"],
["ELE-001","Truck Alternator","electrical","Commercial vehicle alternator",["Mercedes-Benz","Volvo","Scania","MAN","DAF","Iveco"],"Application dependent"],
["ELE-002","Truck Starter Motor","electrical","Heavy-duty diesel starter motor",["Mercedes-Benz","Volvo","Scania","MAN","DAF","Iveco"],"Application dependent"],
["ELE-003","Truck Battery","batteries","Commercial vehicle battery; confirm voltage and capacity",["Mercedes-Benz","Volvo","Scania","MAN","DAF","Hino","Isuzu","Fuso"],"Application dependent"],
["COL-001","Truck Radiator","cooling","Heavy-duty engine cooling radiator",["Mercedes-Benz","Volvo","Scania","MAN","DAF"],"Application dependent"],
["COL-002","Radiator Hose","cooling","Heavy-duty cooling system hose",["Mercedes-Benz","Volvo","Scania","MAN","DAF","Hino","Isuzu"],"Application dependent"],
["LGT-001","LED Truck Headlight","lighting","Commercial vehicle LED lighting component",["Mercedes-Benz","Volvo","Scania","MAN","DAF","Iveco"],"Application dependent"],
["LGT-002","Truck Rear Light","lighting","Heavy-duty rear lighting component",["Mercedes-Benz","Volvo","Scania","MAN","DAF","Hino","Isuzu"],"Application dependent"],
["TYR-001","Heavy Truck Tyre","tyres","Commercial truck tyre; confirm size, axle position and load rating",["Mercedes-Benz","Volvo","Scania","MAN","DAF","Iveco"],"Size and application dependent"],
["TYR-002","Trailer Tyre","tyres","Commercial trailer tyre; confirm size and load rating",["Various"],"Size and application dependent"],
["WHL-001","Truck Steel Rim","wheels","Commercial truck wheel rim",["Mercedes-Benz","Volvo","Scania","MAN","DAF"],"Confirm wheel specification"],
["TRL-001","Trailer Brake Component","trailer","Heavy-duty trailer braking component",["Various"],"Trailer application dependent"],
["TRL-002","Trailer Suspension Component","trailer","Commercial trailer suspension component",["Various"],"Trailer application dependent"],
["BDY-001","Truck Mirror","body","Commercial truck exterior mirror",["Mercedes-Benz","Volvo","Scania","MAN","DAF","Iveco"],"Application dependent"],
["BDY-002","Cabin Component","body","Commercial vehicle cab/body replacement component",["Mercedes-Benz","Volvo","Scania","MAN","DAF"],"Application dependent"],
["EXH-001","Exhaust Component","exhaust","Commercial vehicle exhaust component",["Mercedes-Benz","Volvo","Scania","MAN","DAF","Iveco"],"Application dependent"],
["WRK-001","Workshop Consumables","workshop","General workshop consumables and maintenance products",["Various"],"Workshop application"]
].map(x=>({id:x[0],name:x[1],category:x[2],description:x[3],makes:x[4],models:x[5]}));

const CATEGORY={
engine:"Engine & Components",brakes:"Braking",clutch:"Clutch",gearbox:"Gearbox & Transmission",
drivetrain:"Differentials & Drivetrain",suspension:"Suspension",steering:"Steering",electrical:"Electrical",
cooling:"Cooling",filters:"Filters",lighting:"Lighting",tyres:"Truck & Trailer Tyres",wheels:"Wheels & Rims",
trailer:"Trailer Parts",body:"Cab & Body Parts",exhaust:"Exhaust",batteries:"Batteries",workshop:"Workshop & Consumables"
};
const ICON={engine:"⚙️",brakes:"🛑",clutch:"⚙️",gearbox:"⚙️",drivetrain:"🔩",suspension:"🔧",steering:"🎯",electrical:"⚡",cooling:"❄️",filters:"🧰",lighting:"💡",tyres:"🛞",wheels:"⭕",trailer:"🚚",body:"🚛",exhaust:"💨",batteries:"🔋",workshop:"🧰"};

function cart(){return JSON.parse(localStorage.getItem("kjkCart")||"[]")}
function saveCart(c){localStorage.setItem("kjkCart",JSON.stringify(c))}
function updateCount(){const n=cart().reduce((s,i)=>s+(i.quantity||1),0);const el=document.getElementById("cartCount");if(el)el.textContent=n}
function addProduct(id,q=1){const p=PRODUCTS.find(x=>x.id===id);if(!p)return;const c=cart(),e=c.find(x=>x.id===id);if(e)e.quantity+=q;else c.push({...p,quantity:q,partNumber:p.id});saveCart(c);updateCount();alert(`${p.name} added to your quotation basket.`)}

function render(){
 const term=document.getElementById("search").value.toLowerCase().trim(), cat=document.getElementById("category").value, make=document.getElementById("make").value;
 const list=PRODUCTS.filter(p=>{
  const hay=[p.name,p.description,p.id,...p.makes,p.models].join(" ").toLowerCase();
  return (!term||hay.includes(term))&&(cat==="all"||p.category===cat)&&(make==="all"||p.makes.includes(make)||p.makes.includes("Various"));
 });
 document.getElementById("resultCount").textContent=`${list.length} product${list.length===1?"":"s"} found`;
 document.getElementById("productGrid").innerHTML=list.length?list.map(p=>`
 <article class="product-card"><div class="product-image"><img src="assets/${p.category}.svg" alt="${p.name}"></div>
 <div class="product-info"><div class="category-label">${CATEGORY[p.category]}</div><h2>${p.name}</h2><p>${p.description}</p>
 <div class="part">Part No: <strong>${p.id}</strong></div><div class="compatibility">${p.makes.slice(0,5).map(m=>`<span class="make-tag">${m}</span>`).join("")}</div>
 <div class="card-actions"><button class="details-button" onclick="openProduct('${p.id}')">Details</button><button class="add-button" onclick="addProduct('${p.id}')">Add to Quote</button></div></div></article>`).join(""):`<div class="empty"><h2>No matching parts found</h2><p>Try another search, category or truck make.</p></div>`;
}
let modalProduct=null,modalQuantity=1;
function openProduct(id){modalProduct=PRODUCTS.find(p=>p.id===id);if(!modalProduct)return;modalQuantity=1;document.getElementById("modalImage").innerHTML=`<img src="assets/${modalProduct.category}.svg" alt="${modalProduct.name}">`;document.getElementById("modalCategory").textContent=CATEGORY[modalProduct.category];document.getElementById("modalName").textContent=modalProduct.name;document.getElementById("modalDescription").textContent=modalProduct.description;document.getElementById("modalPart").textContent=modalProduct.id;document.getElementById("modalMakes").textContent=modalProduct.makes.join(", ");document.getElementById("modalModels").textContent=modalProduct.models;document.getElementById("modalQuantity").textContent=1;document.getElementById("productModal").classList.add("active");document.body.style.overflow="hidden"}
function closeModal(){document.getElementById("productModal").classList.remove("active");document.body.style.overflow="";modalProduct=null}
function closeModalOutside(e){if(e.target.id==="productModal")closeModal()}
function changeModalQuantity(n){modalQuantity=Math.max(1,Math.min(99,modalQuantity+n));document.getElementById("modalQuantity").textContent=modalQuantity}
function addModalProduct(){if(modalProduct)addProduct(modalProduct.id,modalQuantity);closeModal()}
document.addEventListener("DOMContentLoaded",()=>{["search","category","make"].forEach(id=>document.getElementById(id).addEventListener("input",render));document.getElementById("category").addEventListener("change",render);document.getElementById("make").addEventListener("change",render);document.getElementById("year").textContent=new Date().getFullYear();render();updateCount()});

# KJK Logistics

Static truck-spares storefront.

## Pages
- `index.html` — homepage
- `products.html` — searchable catalogue
- `cart.html` — quotation basket
- `products.js` — product data and catalogue logic
- `styles.css` / `app.js` — homepage styling and behaviour
- `assets/` — category/product illustrations

## Important
The catalogue uses placeholder part numbers and "Price on Request" until KJK's real inventory, pricing, brands and verified compatibility data are supplied. Do not treat the sample records as confirmed stock.

## Deploy
This is a static site and can be hosted by GitHub Pages, Netlify, Vercel or similar.
